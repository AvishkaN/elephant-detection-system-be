module.exports.permissions = {
  saveData: {
    path: "/",
  },
  getData: {
    path: "/",
  },
};
